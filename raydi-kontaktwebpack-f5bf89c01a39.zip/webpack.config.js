const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');

const devServer = (isDev) => !isDev ? {} : {
	devServer: {
		watchFiles: ["./src/*"], // string [string] object [object]
		open: true,
		hot: true,
		port: 8080,
	}
};

module.exports = ({ develop }) => ({
	mode: develop ? 'development' : 'production',
	entry: {
		main: './src/index.js',
		links: './src/links.js',
		other: './src/other.js',
		faq: './src/faq.js',
		sposobs: './src/sposobs.js',
		politic: './src/politic.js',
		usl: './src/usl.js',
		polvozv: './src/polvozv.js',
		infa: './src/infa.js',
		lk: './src/lk.js',
		catalog: './src/catalog.js',
		catalog1: './src/catalog1.js',
		product: './src/product.js',
		cart: './src/cart.js',
		cartempty: './src/cartempty.js',
		magazines: './src/magazines.js',
		checkout: './src/checkout.js',
		kampaniya: './src/kampaniya.js',
		servicecenter: './src/servicecenter.js',
		sravnenie: './src/sravnenie.js',
		sravnenieempty: './src/sravnenieempty.js',
		reg_login: './src/reg_login.js',
		izbrannoe: './src/izbrannoe.js',
		selfinfa: './src/selfinfa.js',
		notifications: './src/notifications.js',
		notifications2: './src/notifications2.js',
		prosmotr: './src/prosmotr.js',
		history: './src/history.js',
		blog: './src/blog.js',
		blog1: './src/blog1.js',
		errore: './src/errore.js',
		videokonsult: './src/videokonsult.js',
		faq1: './src/faq1.js',
		poisk: './src/poisk.js',
		brand: './src/brand.js',
		poiskempty: './src/poiskempty.js',
	},
	output: {
		path: path.resolve(__dirname, 'dist'),
		filename: '[name].bundle.js',
		chunkFilename: '[id].bundle_[chunkhash].js',
		clean: true,
	},
	plugins: [
		new HtmlWebpackPlugin({
			filename: 'prosmotr.html',
			template: './src/prosmotr.html',
			chunks: ['prosmotr']
		}),
		new HtmlWebpackPlugin({
			filename: 'poiskempty.html',
			template: './src/poiskempty.html',
			chunks: ['poiskempty']
		}),
		new HtmlWebpackPlugin({
			filename: 'brand.html',
			template: './src/brand.html',
			chunks: ['brand']
		}),
		new HtmlWebpackPlugin({
			filename: 'faq1.html',
			template: './src/faq1.html',
			chunks: ['faq1']
		}),
		new HtmlWebpackPlugin({
			filename: 'poisk.html',
			template: './src/poisk.html',
			chunks: ['poisk']
		}),
		new HtmlWebpackPlugin({
			filename: 'videokonsult.html',
			template: './src/videokonsult.html',
			chunks: ['videokonsult']
		}),
		new HtmlWebpackPlugin({
			filename: 'errore.html',
			template: './src/errore.html',
			chunks: ['errore']
		}),
		new HtmlWebpackPlugin({
			filename: 'blog.html',
			template: './src/blog.html',
			chunks: ['blog']
		}),
		new HtmlWebpackPlugin({
			filename: 'blog1.html',
			template: './src/blog1.html',
			chunks: ['blog1']
		}),
		new HtmlWebpackPlugin({
			filename: 'history.html',
			template: './src/history.html',
			chunks: ['history']
		}),
		new HtmlWebpackPlugin({
			filename: 'notifications.html',
			template: './src/notifications.html',
			chunks: ['notifications']
		}),
		new HtmlWebpackPlugin({
			filename: 'notifications2.html',
			template: './src/notifications2.html',
			chunks: ['notifications2']
		}),
		new HtmlWebpackPlugin({
			filename: 'selfinfa.html',
			template: './src/selfinfa.html',
			chunks: ['selfinfa']
		}),
		new HtmlWebpackPlugin({
			filename: 'izbrannoe.html',
			template: './src/izbrannoe.html',
			chunks: ['izbrannoe']
		}),
		new HtmlWebpackPlugin({
			filename: 'index.html',
			template: './src/index.html',
			chunks: ['main']
		}),
		new HtmlWebpackPlugin({
			filename: 'links.html',
			template: './src/links.html',
			chunks: ['links']
		}),
		new HtmlWebpackPlugin({
			filename: 'reg_login.html',
			template: './src/reg_login.html',
			chunks: ['reg_login']
		}),
		new HtmlWebpackPlugin({
			filename: 'other.html',
			template: './src/other.html',
			chunks: ['other']
		}),
		new HtmlWebpackPlugin({
			filename: 'sravnenieempty.html',
			template: './src/sravnenieempty.html',
			chunks: ['sravnenieempty']
		}),
		new HtmlWebpackPlugin({
			filename: 'faq.html',
			template: './src/faq.html',
			chunks: ['faq']
		}),
		new HtmlWebpackPlugin({
			filename: 'politic.html',
			template: './src/politic.html',
			chunks: ['politic']
		}),
		new HtmlWebpackPlugin({
			filename: 'lk.html',
			template: './src/lk.html',
			chunks: ['lk']
		}),
		new HtmlWebpackPlugin({
			filename: 'usl.html',
			template: './src/usl.html',
			chunks: ['usl']
		}),
		new HtmlWebpackPlugin({
			filename: 'sposobs.html',
			template: './src/sposobs.html',
			chunks: ['sposobs']
		}),
		new HtmlWebpackPlugin({
			filename: 'product.html',
			template: './src/product.html',
			chunks: ['product']
		}),
		new HtmlWebpackPlugin({
			filename: 'kampaniya.html',
			template: './src/kampaniya.html',
			chunks: ['kampaniya']
		}),
		new HtmlWebpackPlugin({
			filename: 'polvozv.html',
			template: './src/polvozv.html',
			chunks: ['polvozv']
		}),
		new HtmlWebpackPlugin({
			filename: 'sravnenie.html',
			template: './src/sravnenie.html',
			chunks: ['sravnenie']
		}),
		new HtmlWebpackPlugin({
			filename: 'magazines.html',
			template: './src/magazines.html',
			chunks: ['magazines']
		}),
		new HtmlWebpackPlugin({
			filename: 'checkout.html',
			template: './src/checkout.html',
			chunks: ['checkout']
		}),
		new HtmlWebpackPlugin({
			filename: 'servicecenter.html',
			template: './src/servicecenter.html',
			chunks: ['servicecenter']
		}),
		new HtmlWebpackPlugin({
			filename: 'infa.html',
			template: './src/infa.html',
			chunks: ['infa']
		}),
		new HtmlWebpackPlugin({
			filename: 'catalog.html',
			template: './src/catalog.html',
			chunks: ['catalog']
		}),
		new HtmlWebpackPlugin({
			filename: 'catalog1.html',
			template: './src/catalog1.html',
			chunks: ['catalog1']
		}),
		new HtmlWebpackPlugin({
			filename: 'cart.html',
			template: './src/cart.html',
			chunks: ['cart']
		}),
		new HtmlWebpackPlugin({
			filename: 'cartempty.html',
			template: './src/cartempty.html',
			chunks: ['cartempty']
		}),
		new MiniCssExtractPlugin({
			filename: './styles/main.css'
		})
	],
	module: {
		rules: [
			{
				test: /\.(?:ico|png|jpg|jpeg|svg)$/i,
				type: 'asset/inline'
			},
			{
				test: /\.html$/i,
				loader: 'html-loader'
			},
			{
				test: /\.css$/i,
				use: [
					MiniCssExtractPlugin.loader, 'css-loader'
				]
			},
			{
				test: /\.less$/i,
				use: [
					MiniCssExtractPlugin.loader, 'css-loader', 'less-loader'
				]
			}
		]
	},
	...devServer(develop),
});